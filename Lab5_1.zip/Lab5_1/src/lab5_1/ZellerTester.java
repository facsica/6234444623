
package lab5_1;

import java.util.Scanner;

public class  ZellerTester {

    public static void main(String[] args) {
        System.out.print("Enter year (e.g., 2012): ");
        Scanner year = new Scanner(System.in);
        int y = year.nextInt();
        System.out.print("Enter month (1-12): ");
        Scanner month = new Scanner(System.in);
        int m = month.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        Scanner day = new Scanner(System.in);
        int d = day.nextInt();
        Zeller dayOfweek = new Zeller(d,m,y);
        System.out.println("Day of the week is "+(dayOfweek.getDayOfWeek()).yday);
    }
    
}

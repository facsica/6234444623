/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author asus
 */
public class Zeller {
    private final int dayOfMonth;
    private int month;
    private int year;
    public enum Day { SUNDAY("Sunday"), MONDAY("Monday"),
TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),
FRIDAY("Friday"), SATURDAY("Saturday");
    public final String yday;
    Day(String day){
        yday=day;
    }
    }
    public Zeller(int day,int tmonth,int tyear) {
        dayOfMonth = day;
        month = tmonth;
        year = tyear;
    }
    public Day getDayOfWeek(){
        if (month<3){
            month=month+12;
            year=year-1;
        }
        int j=year/100;
        int k=year%100;
        int dayOfweek=(dayOfMonth+(26*(month+1)/10)+k+(k/4)+(j/4)+(5*j))%7;
        Day theDay = null;
        switch (dayOfweek)
        {
            case 0 : theDay = Day.SATURDAY; break;
            case 1 : theDay = Day.SUNDAY; break;
            case 2 : theDay = Day.MONDAY; break;
            case 3 : theDay = Day.TUESDAY; break;
            case 4 : theDay = Day.WEDNESDAY; break;
            case 5 : theDay = Day.THURSDAY; break;
            case 6 : theDay = Day.FRIDAY; break;
        }
        return theDay ;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

/**
 *
 * @author PC
 */
public class Car {
    protected double nGas ;
    protected final double rate ;
    
public Car (double nGas,double rate){
    this.nGas = nGas;
    this.rate = rate;}
    public void drive(double distance){
        double usedGas = distance/rate;
        if(usedGas>nGas)
            System.out.println("“You cannot drive too far, please add gas");
        
        else  {
            nGas=nGas-usedGas;
        }
    }
    public void setGas(double amount){
       nGas=amount;
    }
    public double getGas(){
        return nGas;
    }
    public double getEfficiency() {
        return rate ;
    }
    public void addGas(double amount){
      nGas+=amount;
    }
}

package Lab10_1;
public class Subject implements Evaluation{
    private String subjName;
    private int score[];
    public Subject(String subjName,int score[]){
        this.subjName = subjName;
        this.score = score;
    }
    public double evaluate() {
        double scores = 0;
        for(int i=0;i<=score.length-1;i++){
            scores = scores+score[i];
        }
        double avgScore = scores/(score.length);
        return avgScore;
    }
    public char grade(double scores) {
        if(scores>=70 && scores<=100){
            return 'P';
        }
        else
            return 'F';
    }
    public String toString(){
        return subjName;
    }
    
}

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;

public class Findword {

    public static void main(String[] args) {
        File f = new File("C:\\Users\\asus\\Documents\\NetBeansProjects\\Lab2_2\\src\\wordlist.txt");
        ArrayList<String> wordlist = new ArrayList<>();
        boolean noword= true;
        try {
            Scanner in = new Scanner(f);
            while (in.hasNextLine())
            {
            String line = in.nextLine();
            wordlist.add(line);
            }
        } 
        catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
        System.out.print("Enter a sentence: ");
        Scanner sentence = new Scanner(System.in);
        
        String[] words = sentence.nextLine().split(" ");
        ArrayList<String> notconWord = new ArrayList<>();
        for(int i=0;i<words.length;i++){
            for(int n=0;n<wordlist.size();n++){
                if(words[i].equals(wordlist.get(n))){
                    noword = false;
                }
                } if(noword) { 
                    notconWord.add(words[i]);
                }
                noword = true;
        }
        System.out.println("Words not contained: ");
        if(notconWord.isEmpty()){
            System.out.println("N/A");
        }
        else{
            for(int i=0;i<notconWord.size();i++){
                System.out.println(notconWord.get(i));
            }
        }
    }
    
}

package Lab10_2;
import java.util.ArrayList;
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        Hybrid hybridBus = new Hybrid(45,1200000,600,150,1);
        arr.add(hybridBus);
        CNGBus cngBus = new CNGBus(50,1000000,200,2);
        arr.add(cngBus);
        for(int i=0;i<=arr.size()-1;i++){
            System.out.println("ID: "+(arr.get(i)).getID());
            if(arr.get(i) instanceof CNGBus){
                System.out.println("Emission Tier: "+((CNGBus)(arr.get(i))).getEmissionTier());
                System.out.println("Accel: "+((CNGBus)(arr.get(i))).getAccel()); }
            else if(arr.get(i) instanceof Hybrid){
                System.out.println("Emission Tier: "+((Hybrid)(arr.get(i))).getEmissionTier());
                System.out.println("Accel: "+((Hybrid)(arr.get(i))).getAccel()); }
            }
        }
    }


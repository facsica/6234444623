package Lab10_2;
public interface LiquidFuel {
    double getRange();
    int getEmissionTier();
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author KNCY
 */
public class TimeInterval {
    
    private final int start;
    private final int stop;
    private final int startResult;
    private final int stopResult;
    
    public TimeInterval(int tStart , int tStop){
        
        start = tStart;
        stop = tStop;     
        int startHour = (start/100)*60;
        int startMinute = (start%100);
        startResult = startHour+startMinute;
        int stopHour = (stop/100)*60;
        int stopMinute = (stop%100);
        stopResult = stopHour+stopMinute;
    
    }
        public int getHours(){
       
       int resultHours = (stopResult-startResult)/60;
       return resultHours;
        
    }
    
    public int getMinutes(){
       
       int resultMinutes = (stopResult-startResult)%60;
       return resultMinutes;
       
    }
}


package lab4_3;
import java.util.Scanner;
public class TimeIntervalTester {
    public static void main(String[] args) {
        Scanner time = new Scanner (System.in);
        System.out.print("Enter start time: ");
        int start = time.nextInt();
        System.out.print("Enter end time: ");
        int stop = time.nextInt();
        TimeInterval fact = new TimeInterval(start,stop);
        System.out.println(fact.getHours()+" hours "+
                            fact.getMinutes()+" minutes");
        
        
        
    }
    
}

package Lab9_2;

public abstract class Taylor {
    
    private int k;
    private double x;
    
    public int factorial(int n) {
        if(n==0)
            return 1;
        return n*factorial(n-1);
    }
    
    public void setIter(int k) {
        this.k=k;
    }
    
    public int getIter() {
        return k;
    }
    
    public void setValue(double x) {
        this.x=x;
    }
    
    public double getValue() {
        return x;
    }
    
    public abstract void printValue();
    public abstract double getApprox();
}
package Lab9_2;

public class sine extends Taylor {
    
    private int k;
    private double x;
    private double sum;
    
    public sine(int k,double x) {
        super.setIter(k);
        super.setValue(x);
        this.k=super.getIter();
        this.x=super.getValue();
    }
    
    @Override
    public double getApprox() {
        for (int i=0;i<=k;i++)
        {
            sum+=((Math.pow(-1, i)*(Math.pow(x, 2*i+1))/super.factorial(2*i+1)));
        }
        return sum;
    }
    
    @Override
    public void printValue() {
        System.out.println("Value from Math.sine() is "+Math.sin(x)+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}
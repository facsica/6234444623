package Lab9_2;

public class cosine extends Taylor {
    
    private int k;
    private double x;
    private double sum;
    
    public cosine(int k,double x) {
        super.setIter(k);
        super.setValue(x);
        this.k=super.getIter();
        this.x=super.getValue();
    }
    
    @Override
    public double getApprox() {
        for (int i=0;i<=k;i++)
        {
            sum+=((Math.pow(-1, i)*(Math.pow(x, 2*i))/super.factorial(2*i)));
        }
        return sum;
    }
    
    @Override
    public void printValue() {
        System.out.println("Value from Math.cos() is "+Math.cos(x)+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}
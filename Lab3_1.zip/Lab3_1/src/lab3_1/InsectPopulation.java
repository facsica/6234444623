/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;



public class InsectPopulation{
     private double Pop ;

public InsectPopulation(double Population){
    Pop = Population ;
    
}

public void breeds(){
     Pop = Pop*2;    
}
    /**
     *}

     */
public void spray(){
    Pop = Pop*90/100;
            
}

public double getNumInsect(){
    return Pop;

}
     
}


   /**
     * @param args the command line arguments
     */
   
    

package lab4_1 ;
import java.util.Scanner;

public class SodaTester {
    
    public static void main(String[] args) {
        Scanner h = new Scanner(System.in) ;
           System.out.print(" Enter height: ");
           double height = h.nextDouble();
           Scanner r = new Scanner(System.in) ;
           System.out.print(" Enter diameter: ");
           double radius = r.nextDouble();
        SodaCan s = new SodaCan(height,radius) ;
        System.out.printf(" Volume : %.2f \n",s.getVolume());
        System.out.printf(" Surface area : %.2f  ",s.getSurfaceArea());
    
  
}
}
package lab4_1;

    public class SodaCan {
        private final double radius ;
        private final double height ;
        private double volume ;
        private double area ;
        public SodaCan (double h,double r){
            height = h;
            radius = r ;        
        }
    public double getVolume () {
        volume = Math.PI*(radius/2)*(radius/2)*height ;
            return volume;
        
    }
    public double getSurfaceArea(){
        area = 2 * Math.PI * (radius/2) * ((radius/2)+ height);
            return area;
    }
    }
    


		

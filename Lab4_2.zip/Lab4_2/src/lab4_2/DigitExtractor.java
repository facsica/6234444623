
package lab4_2;

/**
 *
 * @author KNCY
 */
public class DigitExtractor {

   private int number; 
    
   public DigitExtractor (int anInteger){
       number = anInteger ;
   }
  
   public int nextDigit(){
       int digit = number%10 ;
       number = number/10;
       return digit ;
   }

}
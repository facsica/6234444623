/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class CashRegisterTester {
    public static void main(String[] args) {
       CashRegister Bil = new CashRegister(7.00);
       Bil.recordPurchase(50);
       Bil.recordPurchase(10);
       Bil.recordTaxablePurchase(20);
       Bil.enterPayment(100);
       Bil.getTotalTax();
       System.out.println(Bil.giveChange());
    }
    
}

    


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class CashRegister  {
    private double balance;
    private double tax;
    private double money;
    public CashRegister(double amount)
    {
        tax = amount;
    }
    public void recordPurchase(double price)
    {
        balance = balance + price;
    }
    public void recordTaxablePurchase(double price)
    {
        balance =balance + price;
        money = money + (price*tax/100);
    }
    public void enterPayment(double cash )
    {
        balance = balance+cash ;
    }
    public void getTotalTax()
    {
        balance = balance + money ;
    }
    public double giveChange()
    {
        return balance;
    }
    
}
    


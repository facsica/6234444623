import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
public class Writetext {
    public static void main(String[] args) throws FileNotFoundException {
       File file = new File("text.txt");
       PrintWriter output = new PrintWriter(file);
       String text = "";
       Scanner writer = new Scanner(System.in);
       while(text.equals("quit")==false){
       writer = new Scanner(System.in);
       text = writer.nextLine();
       if(text.equals("quit")) break;
       output.println(text);
       }
       output.close();
       Scanner in = new Scanner(file);
       int countC = 0;
       int countW = 0;
       int countL = 0;
       while (in.hasNextLine())
        {
            String line = in.nextLine();
            for(int i = 0; i<line.length(); i++){
                countC+=1;
            }
            
            String[] words;
            words = line.split(" ");
            countW += words.length;   
            
            countL+= line.split("\n|\r").length;
        }
        
       System.out.println("Total characters : "+countC);
       System.out.println("Total words : "+countW);
       System.out.println("Total lines : "+countL);
       in.close();

    }
    
}

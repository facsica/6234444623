package Lab11_1;
public interface SimpleQueue {
    void enqueue(Object o);
    void dequeue();
}

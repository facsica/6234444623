import java.util.Random;
public class CityGrid {

    private int xC;
    private int yC;
    private final int gridSize;
    private final int x;
    private int y;
    public CityGrid(int x, int y){
        this.xC=x/2;
        this.x=x;
        this.yC=y/2;
        this.y=y;
        this.gridSize=x*y;
    }
    public void walk(){
        Random ran = new Random();
        int walk = ran.nextInt(4);
        switch(walk){
            case 0 : xC++;break;
            case 1 : xC--;break;
            case 2 : y++;break;
            case 3 : yC--;break;
        }
    }
    public boolean isInCity(){
        if ((xC<0 || xC>x) || (yC<0 || yC>y)){
            return false;
        }
        else{
            return true;
        }
    }
    public void reset(){
        xC=x/2;
        yC=y/2;
    }
}
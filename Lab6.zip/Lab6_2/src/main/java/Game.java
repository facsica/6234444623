
import java.util.Scanner;
import java.util.Random;
public class Game {
	private int player;
        private int hP;
        private int cP;   
	private String n;
	private String[] sym= {"ROCK","PAPER","SCISSORS"};
	public Game() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
		n=sc.nextLine();
	}
	public void play() {
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		while(true) {
			if(!n.equals("0") && !n.equals("1") && !n.equals("2")) {
				System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
				n=sc.nextLine();
				continue;
			}
			else {
				player=Integer.parseInt(n);
				int com=rand.nextInt(3);
				System.out.println("You enter: "+sym[player]);
				System.out.println("Computer: "+sym[com]);
				if (player==0 && com==2) {
					hP+=1;
					System.out.println("You win!");
				}
				else if (player==2 && com==0) {
					cP+=1;
					System.out.println("You lose!");
				}
				else if (player>com) {
					hP+=1;
					System.out.println("You win!");
				}
				else if (player<com) {
					cP+=1;
					System.out.println("You lose!");
				}
				else {
					System.out.println("It's a tie.");
				}
				if (hP-cP==2) {
					System.out.println("\n----------------------\n");
					System.out.println("Congrants! You win.");
					System.out.println("User Score: "+hP);
					System.out.println("Computer Score: "+cP);
					break;
				}
				else if (cP-hP==2) {
					System.out.println("\n----------------------\n");
					System.out.println("Too bad! You lose.");
					System.out.println("User Score: "+hP);
					System.out.println("Computer Score: "+cP);
					break;
				}
				System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
			
			}
		}
	}
}

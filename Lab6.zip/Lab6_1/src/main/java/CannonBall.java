/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class CannonBall {
    private double initV; 
    private double simS; 
    private double simT; 
    private double eV ;
    public static final double g = 9.81;
public CannonBall (double V){
    initV = V;
    eV = V ;}

    
public void simulatedFlight() {
    int time = 0;
    while(initV > 0){
       simS = simS+ (initV*0.01) ;
       initV =initV - (0.01*g) ;
       time++  ;
       if (time%100 == 0){
            System.out.printf("Distance on %d sec: %.3f\n",time/100,simS);}
        }
       simT = time/100.0;
       System.out.printf("Final distance: %.3f Total time: %.2f\n",simS,simT);
    }
    
    public double calculusFlight(double t)
    {
        double cal = ((-0.5)*g*Math.pow(t,2))+(eV*t);
        return cal ;
    }
    
    public double getSimulatedTime()
    {
        return simT ;
    }
    
    public double getSimulatedDistance()
    {
        
        return simS ;
    }

       
}
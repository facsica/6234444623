
public class LetterPrinter {
    public static void main(String[] args) {
        Letter Prin = new Letter("Jade","Clarissa");
        Prin.addLine("We must find Simon quickly.");
        Prin.addLine("He might be in danger.");
        System.out.println(Prin.getText());
    }
    

    
}


public class Letter{
    private String from,to,line,word="",text;
    public Letter(String from,String to){this.from=from;this.to=to;}
    public void addLine(String line){word=word+line+"\n";}
    public String getText(){text="Dear "+from+":\n\n"
            +word+"\nSincerely,\n\n"+to;return text;}
}




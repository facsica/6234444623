import java.util.Random;
import java.awt.Rectangle;
public class Lab2_1{
    public static void main(String[] args) {
        Random gen = new Random();
            int x1 = gen.nextInt(51);
            int x2 = gen.nextInt(51);
            int y1 = gen.nextInt(51);
            int y2 = gen.nextInt(51);
            int w1 = gen.nextInt(51);
            int w2 = gen.nextInt(51);
            int h1 = gen.nextInt(51);  
            int h2 = gen.nextInt(51);
        Rectangle r1 = new Rectangle(x1,y1,w1,h1) ;
        Rectangle r2 = new Rectangle(x2,y2,w2,h2) ;
            System.out.println(r1);
            System.out.println(r2);
            Rectangle r3 = r1.intersection(r2);
            System.out.println("Is the intersected rectangle empty?: "+(r3.isEmpty()));
}
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author LENOVO
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar(2020,Calendar.JANUARY,25);
        GregorianCalendar birthday = new GregorianCalendar (2000,Calendar.JUNE,13);
        cal.add(Calendar.DAY_OF_MONTH,100);
        birthday.add(Calendar.DAY_OF_MONTH,10000);
        int weekToday = cal.get(Calendar.DAY_OF_WEEK);
        int dayToday = cal.get(Calendar.DAY_OF_MONTH);
        int monthToday = cal.get(Calendar.MONTH)+1;
        int yearToday = cal.get(Calendar.YEAR);
        int weekBirth = birthday.get(Calendar.DAY_OF_WEEK);
        int dayBirth = birthday.get(Calendar.DAY_OF_MONTH);
        int monthBirth = birthday.get(Calendar.MONTH)+1;
        int yearBirth = birthday.get(Calendar.YEAR);
        System.out.println(weekToday+" "+dayToday+" "+monthToday+" "+yearToday);
        System.out.println(weekBirth+" "+dayBirth+" "+monthBirth+" "+yearBirth);
        
       
    }
    
}

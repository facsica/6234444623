public class PurseTester
{
   public static void main(String[] args)
   {
      Purse a = new Purse();
      a.addCoin("Quarter");
      a.addCoin("Dime");
      a.addCoin("Nickel");
      a.addCoin("Dime");
      
      Purse b = new Purse();
      b.addCoin("Fact");
      b.addCoin("Jessica");
      
      
      System.out.println(a.toString());
      System.out.println("Purse"+ a.reverse());
      a.transfer(b);
      System.out.println(a);
      System.out.println(b);
          
        
        Purse c = new Purse();
        Purse d = new Purse();
        c.addCoin("Quarter");
        c.addCoin("Dime");
        c.addCoin("Nickel");
        c.addCoin("Quarter");
        d.addCoin("Quarter");
        d.addCoin("Dime");
        d.addCoin("Nickel");
        d.addCoin("Quarter");
        System.out.println("c = "+c.toString());
        System.out.println("d = "+d.toString());
        System.out.println("c.sameContents(d) : "+c.sameContents(d)); //test  sameContents
        System.out.println("c.sameCoins(d) : "+c.sameCoins(d));//test  sameCoins
        
        Purse e = new Purse();
        Purse f = new Purse();
        e.addCoin("Quarter");
        e.addCoin("Dime");
        e.addCoin("Nickel");
        f.addCoin("Nickel");
        f.addCoin("Quarter");
        System.out.println("e = "+e.toString());
        System.out.println("f = "+f.toString());
        System.out.println("e.sameContents(f) : "+e.sameContents(f)); //test  sameContents
        System.out.println("e.sameCoins(f) : "+e.sameCoins(f));//test  sameCoins
    }
    
}
;

     
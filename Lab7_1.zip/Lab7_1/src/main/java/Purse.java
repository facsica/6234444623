import java.util.ArrayList;


/**
 *
 * @author usci
 */
public class Purse {
    private  ArrayList<String> coin = new ArrayList<String>();
    public void addCoin(String coinName){
            coin.add(coinName);
    }
    public String toString(){  
         return "Purse" +coin ;} 
    
    public ArrayList<String> reverse() {
       for (int i = 0; i < coin.size()-1 ; i++ )
       coin.add(i, coin.remove (coin.size () - 1));
        return coin;}

    
    
    public void transfer(Purse other)
    {for(int i = 0; i < other.coin.size(); i++ )
          coin.add(other.coin.remove(i+1));}
          
    
    public boolean sameContents(Purse other){
        return this.coin.equals(other.coin);
    }
    public boolean sameCoins(Purse other){
        boolean same = false;
        for(int i =0; i<=this.coin.size()-1; i++){
            for(int n=0; n<=other.coin.size()-1; n++){
                same = this.coin.get(i).equals(other.coin.get(n)) ; 
                if(same==true) break;
                }if(same==false) break;
        }return same;
    }
}   
     

    
